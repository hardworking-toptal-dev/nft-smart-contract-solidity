const developmentChains = ['hardhat', 'localhost']

const WAIT_BLOCK_CONFIRMATIONS = 6

export { developmentChains, WAIT_BLOCK_CONFIRMATIONS }
